public class ItemType {
    private int value;

    public ItemType(int num) {
        this.value = num;
    }
    /*
     * Returns the value instance variable
     */
    public int getValue() {
        return value;
    } // getValue

}
