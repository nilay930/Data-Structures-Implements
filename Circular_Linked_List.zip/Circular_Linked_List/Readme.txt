Compilation Instructions from /dir$

Compile Code
    javac -d bin src/ItemType.java
    javac -cp bin -d bin src/NodeType.java
    javac -cp bin -d bin src/CircularLinkedList.java
    javac -cp bin -d bin src/CircularLinkedListDriver.java

Run Code
    java -cp bin CircularLinkedListDriver file.txt
