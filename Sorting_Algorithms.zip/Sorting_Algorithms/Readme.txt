Compilation Instructions from /dir$:
	javac -d bin src/Sorting.java
	javac -cp bin -d bin src/SortDriver.java

	java -cp bin SortDriver file.txt



The usuage for experiment two has three inputs:
Input 1, where the user writes how many numbers for the randomly filled array
Input 2, where the user will write how many trials the sorting function will be ran on.
The resulting number will be an average of the amount of trials and comparisons.
Input 3, where the user will choose the sorting algorithm,

These will prompt individually.


QuickSort FP and RP:
 	https://www.javadevjournal.com/algorithms/quick-sort/

HeapSort:
	https://www.programiz.com/dsa/heap-sort

SelectionSort:
	https://www.programiz.com/dsa/selection-sort

MergeSort:
	Inclass Slides
